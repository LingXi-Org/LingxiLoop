import {build} from 'vite'
import react from '@vitejs/plugin-react'
import path from 'node:path'
import {mkdir,writeFile,readdir,stat,unlink} from 'node:fs/promises'
const label=process.argv[2], root=path.resolve('roots',label),out=path.resolve('/workspace/diagnose-378-build',label)
process.chdir(root)
const started=performance.now()
await build({configFile:false,root,publicDir:false,plugins:[react()],resolve:{alias:{'@':path.join(root,'src')},dedupe:['react','react-dom','@assistant-ui/react','@assistant-ui/core','@assistant-ui/store','@assistant-ui/tap']},build:{outDir:out,sourcemap:false,reportCompressedSize:false,rollupOptions:{input:path.join(root,'e2e/native-streaming.html')}}})
const retainedMaps=0,removedMaps=0,entry='e2e/native-streaming.html'
await mkdir(path.resolve('/tmp/diagnose-378-memory/receipts'),{recursive:true})
await writeFile(`/tmp/diagnose-378-memory/receipts/build-${label}.json`,JSON.stringify({label,root,out,node:process.version,seconds:(performance.now()-started)/1000,entry,retainedMaps,removedMaps,heapMiB:2048},null,2))
