import { useEffect, useRef, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { AssistantRuntimeProvider, ThreadPrimitive, useExternalStoreRuntime, useAuiState } from '@assistant-ui/react'
import { AssistantStream, AssistantTransportEncoder, type AssistantStreamChunk } from 'assistant-stream'
import { createRunView } from '@lyyzka/lingxios/ui'
import { createNativeMessage } from '@/lib/nativeMessage'
import { harnessApi } from '@/features/chat/runtime/harness-api'
import { applyRunSnapshot } from '@/features/chat/runtime/run-updates'
import { EMPTY_CONVERSATION_CHAT_STATE, messageKey, mergeCanonicalMessages, resetChatThreadStore, setConversationMessages, updateConversation, useChatThreadStore } from '@/features/chat/runtime/store'
import { convertEnvelope } from '@/features/chat/runtime/converter'
import { ConversationMessage } from '@/features/chat/components/ConversationMessage'
import { useAuth } from '@/stores/auth'
import { useParticipants } from '@/features/agents/state'
import '@/styles/globals.css'

const metrics = { streamsOpened:0, streamsCancelled:0, activeStreams:0, decoded:0, emitted:0, effectMounts:0, effectCleanups:0, alerts:[] as string[] }
const participant = { id:'agent', kind:'agent' as const, name:'合成辅导员', initial:'辅', avatarBg:'#26734d', status:'working' as const, statusUpdatedAt:'2026-10-24T07:00:00Z' }
const human = { id:'student', kind:'human' as const, name:'合成学生', initial:'学', avatarBg:'#556677', status:'avail' as const }
useAuth.setState({activeCompanyId:'company',user:{id:'student'} as never})
useParticipants.setState({byId:{agent:participant,student:human},loaded:true})
const wires = new Map<string,ReadableStreamDefaultController<AssistantStreamChunk>>()
const records = new Map<string,{text:string;version:number;sequence:number;running:boolean}>()
let producer: number|undefined
const fetchOriginal = window.fetch
window.fetch = async (url,init) => {
 const match=/\/channels\/([^/]+)\/agents\/agent\/runs\/run\/stream\?/.exec(String(url))
 if(!match)return fetchOriginal(url,init)
 const room=decodeURIComponent(match[1]!)
 metrics.streamsOpened++;metrics.activeStreams++
 let cancelled=false
 const cancel=()=>{if(cancelled)return;cancelled=true;metrics.streamsCancelled++;metrics.activeStreams--;wires.delete(room)}
 const stream=new ReadableStream<AssistantStreamChunk>({start(controller){wires.set(room,controller)},cancel})
 init?.signal?.addEventListener('abort',cancel,{once:true})
 return AssistantStream.toResponse(stream,new AssistantTransportEncoder())
}
const activity={providerMetadata:{lingxiloop:{activity:{version:1,id:'answer:1:0',kind:'answer',label:'答复'}}}}
function send(room:string,append?:string,cancelled=false){
 const record=records.get(room)!;const wire=wires.get(room);if(!wire)throw new Error('synthetic stream is not ready')
 record.sequence++
 if(append!==undefined){record.text+=append;wire.enqueue({type:'update-state',path:[],operations:[
  {type:'append-text',path:['message','content','0','text'],value:append},
  {type:'set',path:['message','metadata','custom','harness','lastSeq'],value:record.sequence},
 ]});metrics.emitted++;return}
 const message=createNativeMessage({id:'run-run',role:'assistant',createdAt:'2026-10-24T07:00:00Z',
  content:[{type:'text',text:record.text,...activity}],status:cancelled?{type:'incomplete',reason:'cancelled'}:{type:'running'},
  custom:{runId:'run',activityPresentation:{version:1},harness:{...createRunView('run'),requestVersion:record.version,fence:record.version,lastSeq:record.sequence,
    lifecycle:cancelled?'cancelled':'leased',delivery:null,artifacts:[]}}})
 wire.enqueue({type:'update-state',path:[],operations:[{type:'set',path:[],value:{message} as never}]});metrics.emitted++
}
function seed(room:string,count:number){
 const messages=Array.from({length:count},(_,index)=>{
  const user=index%2===0;const fromUid=user?'student':'agent';const id=`${room}-history-${index}`
  const text=user?`合成练习 ${index}：我先尝试计算地址数量。`:`### 合成讲解 ${index}\n\n已有推导：**子网容量**与边界需要同时核对。\n\n- 先列条件\n- 再验证结论\n\n${'保持学生原始思路，提供一个独立核对步骤。'.repeat(3)}`
  const payload=createNativeMessage({id,role:user?'user':'assistant',createdAt:new Date(index*1000).toISOString(),content:[{type:'text',text}],status:{type:'complete',reason:'stop'}})
  return convertEnvelope({channelId:room,fromUid,clientMsgNo:id,messageId:id,messageSeq:index+1,timestamp:index+1,payload} as never,{participants:{agent:participant,student:human},meId:'student'})
 })
 setConversationMessages(room,messages,'merge')
}
const components={Message:ConversationMessage}
function Messages(){const messages=useAuiState(s=>s.thread.messages);return messages.map((message,index)=><ThreadPrimitive.MessageByIndex key={messageKey(message)} index={index} components={components}/>)}
function Room({id}:{id:string}){
 const state=useChatThreadStore(s=>s.conversations[id]??EMPTY_CONVERSATION_CHAT_STATE)
 useEffect(()=>{
  metrics.effectMounts++;const abort=new AbortController();const target={conversationId:id,agentId:'agent',runId:'run'}
  void harnessApi.subscribe(target,snapshot=>{metrics.decoded++;updateConversation(id,state=>applyRunSnapshot(state,target,snapshot,participant))},abort.signal)
    .catch(error=>{if(!abort.signal.aborted)metrics.alerts.push(String(error))})
  return()=>{metrics.effectCleanups++;abort.abort()}
 },[id])
 const runtime=useExternalStoreRuntime({messages:state.messages,isRunning:Object.keys(state.activeRuns).length>0,onNew:async()=>{}})
 return <AssistantRuntimeProvider runtime={runtime}><ThreadPrimitive.Root style={{height:650}}><ThreadPrimitive.Viewport style={{height:'100%',overflowY:'auto'}}><Messages/></ThreadPrimitive.Viewport></ThreadPrimitive.Root></AssistantRuntimeProvider>
}
function App(){
 const [room,setRoom]=useState('room-a');const [shown,setShown]=useState(true);const current=useRef(room);current.current=room
 useEffect(()=>{
  const inspect=()=>({ ...metrics, activeStreams:metrics.activeStreams, rooms:Object.entries(useChatThreadStore.getState().conversations).map(([id,s])=>({id,messages:s.messages.length,characters:s.messages.reduce((n,m)=>n+m.content.reduce((sum,p)=>sum+('text'in p?String(p.text).length:0),0),0)})),
    fixtureRecordCharacters:[...records.values()].reduce((n,r)=>n+r.text.length,0),producerActive:producer!==undefined,shown,room})
  const control={inspect,
   expand(){seed(current.current,128)},
   start(){const id=current.current;const previous=records.get(id);records.set(id,{text:previous?.text??'## 合成流式说明\n\n',version:(previous?.version??0)+1,sequence:(previous?.sequence??0)+1,running:true});send(id)
    if(producer!==undefined)clearInterval(producer)
    producer=window.setInterval(()=>send(id,'继续解释**子网边界**，保留原始推导与下一步验证。\n'),40)},
   stop(){if(producer!==undefined)clearInterval(producer);producer=undefined;const id=current.current;if(records.has(id)&&wires.has(id))send(id,undefined,true)},
   switch(){if(producer!==undefined)clearInterval(producer);producer=undefined;const next=current.current==='room-a'?'room-b':'room-a';if(!useChatThreadStore.getState().conversations[next])seed(next,128);setRoom(next)},
   unmount(){if(producer!==undefined)clearInterval(producer);producer=undefined;setShown(false)},
   reset(){resetChatThreadStore();records.clear()},
  }
  Object.assign(window,{__diag:control})
 },[shown,room])
 return <main style={{maxWidth:1000,margin:'16px auto'}} data-room={room} data-shown={shown}><input aria-label="响应检查"/>{shown?<Room key={room} id={room}/>:<p>合成组件已卸载</p>}</main>
}
seed('room-a',64)
createRoot(document.getElementById('root')!).render(<App/> )
