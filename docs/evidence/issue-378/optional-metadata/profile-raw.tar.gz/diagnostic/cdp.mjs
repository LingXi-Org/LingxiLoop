import WebSocket from 'ws'
import {writeFile} from 'node:fs/promises'
export async function profilePage(exactURL,label){
 const targets=await fetch('http://127.0.0.1:9337/json/list').then(r=>r.json())
 const own=targets.filter(t=>t.type==='page'&&t.url===exactURL)
 if(own.length!==1)throw new Error(`Expected one synthetic ownpage, got ${own.length}`)
 const target=own[0],socket=new WebSocket(target.webSocketDebuggerUrl);await new Promise((resolve,reject)=>{socket.once('open',resolve);socket.once('error',reject)})
 let sequence=0;const pending=new Map()
 socket.on('message',bytes=>{const value=JSON.parse(bytes);const p=pending.get(value.id);if(!p)return;pending.delete(value.id);clearTimeout(p.timer);value.error?p.reject(new Error(JSON.stringify(value.error))):p.resolve(value.result)})
 const send=(method,params={})=>new Promise((resolve,reject)=>{const id=++sequence;const timer=setTimeout(()=>{pending.delete(id);reject(new Error(method+' timed out'))},10000);pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params}))})
 const began=Date.now();await send('Performance.enable');await send('Profiler.enable');await send('Profiler.setSamplingInterval',{interval:1000});await send('HeapProfiler.enable');await send('HeapProfiler.startSampling',{samplingInterval:131072,includeObjectsCollectedByMajorGC:false,includeObjectsCollectedByMinorGC:false});await send('Profiler.start')
 const checkpoints=[]
 return {async checkpoint(phase,fixture){const result=await send('Performance.getMetrics');const metrics=Object.fromEntries(result.metrics.map(x=>[x.name,x.value]));const value={phase,wallUTC:new Date().toISOString(),metrics,fixture};checkpoints.push(value);await writeFile(`results/${label}/checkpoints-partial.json`,JSON.stringify({targetId:target.id,exactURL,checkpoints},null,2));return value},
 async stop(){const cpu=await send('Profiler.stop');const heap=await send('HeapProfiler.stopSampling');await send('Performance.disable');await send('Profiler.disable');await send('HeapProfiler.disable');socket.close();
  const provenance={label,targetId:target.id,exactURL,source:'official app.open -> browser.url exact match in existing CDP target metadata; no other page session attached',cpuIntervalUs:1000,heapIntervalBytes:131072,forcedGC:false,elapsedWallMs:Date.now()-began,overhead:'CPU/allocation profilers plus same JS probes enabled on both sides; no unprofiled control run',checkpoints};
  await writeFile(`results/${label}/cpu.cpuprofile`,JSON.stringify(cpu.profile));await writeFile(`results/${label}/heap-sampling.json`,JSON.stringify(heap.profile));await writeFile(`results/${label}/checkpoints.json`,JSON.stringify(provenance,null,2));return provenance}
 }
}
