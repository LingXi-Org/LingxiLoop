(() => {
 localStorage.clear();sessionStorage.clear();
 const samples=[],longtasks=[],frames=[],errors=[];let last=0,probeMs=0,commits=0,unmounts=0,changes=0,observerBatches=0,avatarChanges=0,markdownChanges=0
 const originalRAF=requestAnimationFrame.bind(window),originalCancel=cancelAnimationFrame.bind(window),originalSet=setTimeout.bind(window),originalClear=clearTimeout.bind(window)
 const timeouts=new Set(),intervals=new Set(),rafs=new Set()
 window.setTimeout=(fn,delay,...args)=>{let id;id=originalSet(()=>{timeouts.delete(id);typeof fn==='function'?fn(...args):eval(fn)},delay);timeouts.add(id);return id}
 window.clearTimeout=id=>{timeouts.delete(id);originalClear(id)}
 const originalInterval=setInterval.bind(window),originalClearInterval=clearInterval.bind(window)
 window.setInterval=(fn,delay,...args)=>{const id=originalInterval(fn,delay,...args);intervals.add(id);return id}
 window.clearInterval=id=>{intervals.delete(id);originalClearInterval(id)}
 window.requestAnimationFrame=fn=>{let id;id=originalRAF(t=>{rafs.delete(id);fn(t)});rafs.add(id);return id}
 window.cancelAnimationFrame=id=>{rafs.delete(id);originalCancel(id)}
 Object.assign(window,{__REACT_DEVTOOLS_GLOBAL_HOOK__:{supportsFiber:true,renderers:new Map(),inject(renderer){this.renderers.set(1,renderer);return 1},onCommitFiberRoot(){commits++},onCommitFiberUnmount(){unmounts++},checkDCE(){}}})
 if(PerformanceObserver.supportedEntryTypes.includes('longtask'))new PerformanceObserver(list=>{for(const e of list.getEntries())longtasks.push({start:e.startTime,duration:e.duration,name:e.name})}).observe({type:'longtask',buffered:true})
 addEventListener('error',e=>errors.push(String(e.message)))
 addEventListener('unhandledrejection',e=>errors.push(String(e.reason)))
 const frame=t=>{if(last&&frames.length<12000)frames.push({at:t,delta:t-last});last=t;originalRAF(frame)};originalRAF(frame)
 const sample=phase=>{const start=performance.now();const md=document.querySelectorAll('.im-markdown');const m=performance.memory;const data={at:start,phase,heap:m?{used:m.usedJSHeapSize,total:m.totalJSHeapSize,limit:m.jsHeapSizeLimit}:null,dom:document.querySelectorAll('*').length,markdown:md.length,words:document.querySelectorAll('[data-streaming-word]').length,avatars:document.querySelectorAll('[data-message-avatar] svg').length,svgPaths:document.querySelectorAll('svg path').length,animations:document.getAnimations().length,activeRAF:rafs.size,activeTimeouts:timeouts.size,activeIntervals:intervals.size,commits,unmounts,changes,observerBatches,avatarChanges,markdownChanges,visibleText:[...md].reduce((n,e)=>n+(e.textContent?.length??0),0)};probeMs+=performance.now()-start;samples.push(data);return data}
 const ready=()=>{new MutationObserver(records=>{const begin=performance.now();observerBatches++;changes+=records.length;for(const record of records){const node=record.target.nodeType===1?record.target:record.target.parentElement;if(node?.closest?.('.bloub-avatar-alive'))avatarChanges++;else if(node?.closest?.('.im-markdown'))markdownChanges++}probeMs+=performance.now()-begin}).observe(document.getElementById('root'),{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['d','transform']})};addEventListener('DOMContentLoaded',ready,{once:true})
 originalInterval(()=>sample('periodic'),500)
 Object.assign(window,{__profile:{sample,read:()=>({samples,longtasks,frames,errors,probeMs,reactCommitCount:commits,reactUnmountCount:unmounts,reactComponentRenderCounts:'not instrumented; production commit hook only',markdownRenderCounts:'not exposed; mutations are not render calls',gc:'not forced or directly observed by JS heap API',instrumentation:'same 500ms DOM sample, rAF interval, longtask observer, timer ID counters, O(1) React commit hook in both builds'})}})
})()
