import {web} from '@e2e-dev/web'
import type {E2EConfig} from 'e2e'
const label=process.env.DIAG_SIDE==='baseline'?'baseline':'candidate'
export default {projectId:'378-bounded-memory-diagnosis',tests:['profile.e2e.ts'],targets:[{name:'web',engine:web({browser:'chromium',viewport:{width:1100,height:900},locale:'zh-CN',connect:{cdpEndpoint:()=> 'http://127.0.0.1:9337'}}),app:{url:`http://127.0.0.1:${label==='baseline'?5195:5196}`,command:{executable:process.execPath,args:['serve.mjs',label],startupTimeout:30000,log:`results/${label}/server.log`}}}],workers:1,retries:0,timeout:120000,assertionTimeout:15000,output:`results/${label}/official`,trace:'off',video:'off',reporters:['list','markdown','junit']} satisfies E2EConfig
