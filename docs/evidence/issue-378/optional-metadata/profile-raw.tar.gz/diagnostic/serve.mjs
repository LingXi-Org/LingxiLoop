import {createServer} from 'node:http'
import {readFile} from 'node:fs/promises'
import {resolve,extname} from 'node:path'
const label=process.argv[2],port=label==='baseline'?5195:5196,root=resolve('/workspace/diagnose-378-build',label)
const types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.woff':'font/woff','.woff2':'font/woff2','.ttf':'font/ttf','.json':'application/json','.png':'image/png','.svg':'image/svg+xml'}
const server=createServer(async(req,res)=>{try{const path=new URL(req.url,'http://localhost').pathname;const file=resolve(root,'.'+decodeURIComponent(path));if(!file.startsWith(root+'/'))throw new Error('outside');const bytes=await readFile(file);res.setHeader('content-type',types[extname(file)]??'application/octet-stream');res.setHeader('cache-control','no-store');res.end(bytes)}catch{res.statusCode=404;res.end('not found')}})
server.listen(port,'127.0.0.1');for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>server.close(()=>process.exit(0)))
