import {test} from '@e2e-dev/web'
import {expect} from 'e2e'
import {readFile,mkdir,writeFile} from 'node:fs/promises'
import {profilePage} from './cdp.mjs'
const label=process.env.DIAG_SIDE==='baseline'?'baseline':'candidate'
test('one bounded sustained native stream and three cancel/switch/restore cycles',async({app,browser})=>{
 await mkdir(`results/${label}`,{recursive:true});await browser.addInitScript(await readFile('monitor.js','utf8'))
 const blocked:string[]=[]
 await browser.route(/^https?:\/\//,async route=>{const u=new URL(route.request.url);if(u.hostname==='127.0.0.1'&&[5195,5196].includes(Number(u.port))&&!u.pathname.startsWith('/api'))await route.continue();else{blocked.push(u.origin+u.pathname);await route.abort()}})
 await app.open(`/e2e/native-streaming.html?diagnostic=378-${label}`)
 await expect.poll(()=>browser.evaluate(()=>Boolean((window as any).__diag?.inspect().activeStreams))).toBe(true)
 const session=await profilePage(await browser.url(),label)
 const point=async(phase:string)=>{const fixture=await browser.evaluate(phase=>({monitor:(window as any).__profile.sample(phase),fixture:(window as any).__diag.inspect()}),phase);await session.checkpoint(phase,fixture);console.log(`CHECKPOINT ${label} ${phase} ${JSON.stringify(fixture)}`)}
 const switchRoom=async()=>{const previous=await browser.evaluate(()=>(window as any).__diag.inspect().streamsOpened);await browser.evaluate(()=>{(window as any).__diag.switch();return true});await expect.poll(()=>browser.evaluate(()=>(window as any).__diag.inspect().streamsOpened)).toBeGreaterThan(previous);await expect.poll(()=>browser.evaluate(()=>(window as any).__diag.inspect().activeStreams)).toBe(1)}
 const wait=async(ms:number)=>browser.evaluate(ms=>new Promise(resolve=>setTimeout(()=>resolve(true),ms)),ms)
 try{
  await point('mounted64-idle');await wait(1000);await point('mounted64-idle-1s');await browser.evaluate(()=>{(window as any).__diag.start();return true})
  for(let step=0;step<4;step++){await wait(5000);if(step===1)await browser.evaluate(()=>{(window as any).__diag.expand();return true});await point(`stream-${(step+1)*5}s`)}
  await browser.locator('input').fill('流式中保留输入')
  await browser.evaluate(()=>{(window as any).__diag.stop();return true});await wait(500);await point('cancelled-after-20s')
  for(let cycle=0;cycle<3;cycle++){
   await switchRoom()
   await browser.evaluate(()=>{(window as any).__diag.start();return true});await wait(500);await browser.evaluate(()=>{(window as any).__diag.stop();return true});await wait(250);await point(`cycle-${cycle+1}-away-cancelled`)
   await switchRoom()
   await browser.evaluate(()=>{(window as any).__diag.start();return true});await wait(500);await browser.evaluate(()=>{(window as any).__diag.stop();return true});await wait(250);await point(`cycle-${cycle+1}-restored-cancelled`)
  }
  await browser.evaluate(()=>{(window as any).__diag.unmount();return true});await wait(1000);await point('unmounted-store-retained')
  await browser.evaluate(()=>{(window as any).__diag.reset();return true});await wait(3000);await point('store-reset-settled')
  const data=await browser.evaluate(()=>({monitor:(window as any).__profile.read(),fixture:(window as any).__diag.inspect(),environment:{ua:navigator.userAgent,dpr:devicePixelRatio,width:innerWidth,height:innerHeight,visibility:document.visibilityState},blocked:[]}))
  await writeFile(`results/${label}/browser.json`,JSON.stringify({...data,blocked},null,2));expect(data.fixture.activeStreams).toBe(0);expect(data.fixture.producerActive).toBe(false);expect(data.fixture.rooms).toHaveLength(0);expect(data.fixture.alerts).toHaveLength(0)
 }finally{await session.stop()}
})
