# #378 bounded native-stream memory diagnosis

Only one matched browser sample per source, after two authorized serial
production builds. Source snapshots are Git exports, never product-file edits.
A: d3227695 (A/B/C deployed source). B:033fa2dd (A–G); Git comparison confirms
src/lock/dependency-helper bytes equal main55f62548. Locks and fixture hashes
are in preflight.json. Existing formal dependencies are read-only symlinks.

Use existing Chrome/CDP9337/profile/flags, official tester-army/@e2e-dev/web for
all page interaction. Attach the existing ws client only to the exact synthetic
URL opened by that engine, recording its unique target ID. Performance/CPU and
allocation sampling are supplemental CDP diagnostics, not official E2E assertions.
No forced GC, extra browser, provider, DB, private page or production read.

Same common fixture on both sides: real harnessApi.subscribe, encoded
AssistantTransport append-text operations, actual publication/validation,
applyRunSnapshot/canonical store, external runtime, stable MessageByIndex keys
and full ConversationMessage/Markdown/avatar. Initial64 history messages,
expand to128 after10s of a fixed20s stream, then3 cancel/switch/restore cycles,
unmount, inspect intentionally retained conversation store, reset with the
product's existing reset function and settle3s. This is a synthetic component
lifecycle/decoder/store replay; full ChatTransport/navigation, server lifecycle,
artifacts and real user/device frame rate are outside the measurement.

Capture CPU profiler1ms, allocation sampling128KiB, CDP heap/DOM/listeners and
script/layout/task totals at phase boundaries. Same JS longtask/rAF/timer-ID
probes, 500ms DOM/word/animation/heap samples and O(1) React commit-hook counts
on both sides. No production React component/Markdown render counts are exposed;
DOM mutations are labelled as mutations. Probe time and profiler settings are
recorded; no extra unprofiled control run is planned. Natural GC is identified
only if CPU samples include it; a heap decrease alone is not proof of GC or leak.

The first baseline build used hidden maps to locate CPU stacks and hit the
approved2048MiB Node heap at chunk rendering (exit134, log retained). No browser
sample resulted. Root approved one new no-map build per source at the same heap,
with large output isolated under /workspace/diagnose-378-build. CPU locations
remain minified; no larger heap, new flags/maps or repeated sample follows.
