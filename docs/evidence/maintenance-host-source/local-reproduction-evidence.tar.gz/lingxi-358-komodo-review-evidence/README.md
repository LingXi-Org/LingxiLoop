# Local Komodo2.3.3 Git reproduction

These artifacts contain local-only tests. No production API/host was accessed, no production configuration was changed and no credential was copied. The official-source downloads are public unauthenticated GitHub reads. Product Git objects are read through Git alternates; all new objects, refs, reflogs and checkouts belong to the disposable local fake origin. Failure conditions were written first in `/tmp/lingxi-358-komodo-git-failure-model.md`.

Observed Git version:2.52.0. The production hosts' Git versions were not verified. Actual production's recorded CoreB rebase error matches the local stopped commit, replay position and five conflict paths exactly; other production Git failures are not automatically attributed to that cause.

## Repeat on this workspace without touching prior evidence

Use a new output directory for each run:

```bash
komodo_repro_dir=$(mktemp -d /tmp/komodo-git-local.XXXXXX)
export KOMODO_LOCAL_REPRO_DIR="$komodo_repro_dir"
export KOMODO_REPRO_OBJECTS="$(git -C /workspace/LingxiLoop-integration-215-216-219 rev-parse --path-format=absolute --git-path objects)"
python3 /tmp/lingxi-358-komodo-git-repro/reproduce.py
python3 /tmp/lingxi-358-komodo-git-repro/reproduce_fresh.py
python3 /tmp/lingxi-358-komodo-git-repro/verify_results.py
```

Git must have all three existing commits: old pin5d00ad7e379d82ea8b5ab35c10af775b155717f2, mainc6c47bddeabb4488f9fe93391f15c695a528260c, targetf56db73dabbaec1e92a421bbad76c239ed8d1ae2, and the historical ancestor commits referenced in the script. Existing source object store is never written. The only extra commit is a local fake-origin linear-history control with the same tree asf56. It is not pushed anywhere.

Each experiment uses the official command order: set local origin, fetch all/prune, force-checkout configured branch, pull with rebase/force, then exact commit reset. Every command, exit status and stdout/stderr is recorded. Fresh experiments recreate only their own `fresh-checkout` directory and record rebase journal values, HEAD/tree, fork-point and conflict paths before/after.

## Results

- Initial sequence:16 cases. The old source pin behindmain passes3/3; transition to targetf56 succeeds once. The next main/f56 operation reproduces the production-style conflict. Later retries show residual rebase state.
- Independent sequence:18 cases. Three genuinely new main/f56 checkouts each fail at06c0a1be, replay2/66, with the same5add/add conflicts.
- Clean fixed release branch atf56 passes8/8 repeated operations with exact target HEAD/tree and no rebase journal.
- Switching an already conflicted checkout to the fixed release branch returns success while the previous rebase journal remains. This is not evidence of a clean cache.
- A same-tree linear child ofmain passes. An artificial upstream rewind changes fork-point selection and can also pass. Neither scenario is claimed to represent production; they distinguish graph/reflog effects.
- Historical divergent issue215 commits pass in separate fresh cases; divergence alone is not a sufficient explanation.
- A separate local nonexistent-origin clone fixture ends128 with its previously removed owned checkout absent. This demonstrates the missing-root failure shape only, not production's network or authentication cause.

`verify_results.py` verifies the reported assertions from the persisted receipts. `official-sources.json` binds8public v2.3.3 sources to URLs and SHA-256; all8 match the previously reviewed local copies. `compose-hashes.json` contains exact source/target raw Compose hashes, including unchanged core-state content.

See `/tmp/lingxi-358-komodo-git-root-cause-review.md` for the full interpretation, limits and host-file-mode contract.
