from pathlib import Path
import os,json
p=Path(os.environ.get('KOMODO_LOCAL_REPRO_DIR','/tmp/lingxi-358-komodo-git-repro'))
a=json.loads((p/'summary.json').read_text());b=json.loads((p/'fresh-summary.json').read_text());r={x['name']:x for x in b['results']};target=a['targetPin']
expected_paths=['docs/evidence/issue-215-public/FAILURE-MODEL.md','server/src/__integration__/durable-public-activity.test.ts','server/src/__integration__/public-activity-history.test.ts','server/src/__tests__/durable-public-projection.test.ts','src/features/chat/runtime/public-history-loading.test.ts']
for i in range(1,4):
 x=r['fresh_main_target_'+str(i)];assert not x['success'];assert x['after']['rebase']['stopped-sha']=='06c0a1befa6b9516e97ee04b94dd44af8b11d220';assert x['after']['rebase']['msgnum']=='2' and x['after']['rebase']['end']=='66';assert x['after']['conflicts']==expected_paths
for prefix in ['clean_main_to_matching_release_','fresh_matching_release_']:
 for i in range(1,5):
  x=r[prefix+str(i)];assert x['success'] and x['after']['head']==target and x['after']['tree']=='f094b31bec8b10429213321ec0e7bed0f6611373' and not x['after']['rebase'] and not x['after']['conflicts']
assert not r['produce_interrupted_rebase']['success']
assert r['switch_release_with_stale_rebase']['success'] and r['switch_release_with_stale_rebase']['after']['rebase']
assert not r['ancestor_ref_reflog']['success'] and r['rewound_ref_reflog']['success']
assert r['rewound_ref_reflog']['before']['forkPointMain']==target
assert r['linear_ahead_control']['success'] and not r['linear_ahead_control']['after']['rebase']
assert all(x['success'] for x in a['results'] if x['name'].startswith('old_pin_behind_main_') or x['name']=='transition_old_to_target')
print(json.dumps({'verification':'PASS','gitVersion':b['gitVersion'],'initialCases':len(a['results']),'independentCases':len(b['results']),'cleanMainTargetFailureReproductions':3,'cleanReleaseBranchSuccesses':8,'sameTreeLinearControl':'pass','staleRebaseSurvivesBranchSwitch':True},indent=2))
