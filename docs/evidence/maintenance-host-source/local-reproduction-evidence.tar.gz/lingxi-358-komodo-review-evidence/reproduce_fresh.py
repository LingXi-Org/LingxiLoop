import os,subprocess,time,json,pathlib,shutil
ROOT=pathlib.Path(os.environ.get('KOMODO_LOCAL_REPRO_DIR','/tmp/lingxi-358-komodo-git-repro'));ROOT.mkdir(parents=True,exist_ok=True);ORIGIN=ROOT/'origin.git';CHECKOUT=ROOT/'fresh-checkout';MAIN='c6c47bddeabb4488f9fe93391f15c695a528260c';OLD='5d00ad7e379d82ea8b5ab35c10af775b155717f2';TARGET='f56db73dabbaec1e92a421bbad76c239ed8d1ae2';BRANCH='release/production-358-20261020';EVENTS=[];RESULTS=[]
env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')};env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_TERMINAL_PROMPT':'0','GIT_ALLOW_PROTOCOL':'file','GIT_EDITOR':'true','GIT_SEQUENCE_EDITOR':'true'})
base=['git','-c','core.hooksPath=/dev/null','-c','protocol.file.allow=always','-c','user.name=leecyang','-c','user.email=164771957+leecyang@users.noreply.github.com']
def run(cwd,args,tag='setup',required=True,input=None):
 start=time.monotonic();p=subprocess.run(base+args,cwd=cwd,env=env,text=True,capture_output=True,timeout=120,input=input);EVENTS.append({'tag':tag,'cwd':str(cwd),'args':args,'code':p.returncode,'elapsedMs':round((time.monotonic()-start)*1000,2),'stdout':p.stdout,'stderr':p.stderr});(ROOT/'fresh-commands.json').write_text(json.dumps(EVENTS,indent=2)+'\n')
 if required and p.returncode:raise RuntimeError(json.dumps(EVENTS[-1]))
 return p
def state():
 rb=CHECKOUT/'.git/rebase-merge';fields={n:(rb/n).read_text().strip() for n in ['head-name','onto','orig-head','stopped-sha','msgnum','end'] if (rb/n).exists()}
 return {'head':run(CHECKOUT,['rev-parse','HEAD'],'state').stdout.strip(),'tree':run(CHECKOUT,['rev-parse','HEAD^{tree}'],'state').stdout.strip(),'forkPointMain':run(CHECKOUT,['merge-base','--fork-point','refs/remotes/origin/main','HEAD'],'state',False).stdout.strip(),'rebase':fields,'conflicts':run(CHECKOUT,['diff','--name-only','--diff-filter=U'],'state').stdout.splitlines()}
def fresh(commit=TARGET,branch='main'):
 if CHECKOUT.exists():
  assert CHECKOUT.parent==ROOT and CHECKOUT.name=='fresh-checkout' and not CHECKOUT.is_symlink();shutil.rmtree(CHECKOUT)
 run(ROOT,['clone','--shared',str(ORIGIN),str(CHECKOUT),'-b',branch]);run(CHECKOUT,['config','gc.auto','0']);run(CHECKOUT,['reset','--hard',commit])
def pull(branch,pin,name):
 before=state();rows=[]
 for args in [['remote','set-url','origin',str(ORIGIN)],['fetch','--all','--prune'],['checkout','-f',branch],['pull','--rebase','--force','origin',branch],['reset','--hard',pin]]:
  p=run(CHECKOUT,args,name,False);rows.append({'args':args,'code':p.returncode})
  if p.returncode:break
 d={'name':name,'before':before,'after':state(),'success':all(r['code']==0 for r in rows),'commands':rows};RESULTS.append(d);(ROOT/'fresh-results.json').write_text(json.dumps(RESULTS,indent=2)+'\n');print(json.dumps({'name':name,'success':d['success'],'after':d['after']}),flush=True)
for i in range(3):fresh();pull('main',TARGET,'fresh_main_target_'+str(i+1))
fresh()
for i in range(4):pull(BRANCH,TARGET,'clean_main_to_matching_release_'+str(i+1))
fresh(TARGET,BRANCH)
for i in range(4):pull(BRANCH,TARGET,'fresh_matching_release_'+str(i+1))
fresh();pull('main',TARGET,'produce_interrupted_rebase');pull(BRANCH,TARGET,'switch_release_with_stale_rebase')
fresh();run(CHECKOUT,['update-ref','--create-reflog','-m','local fixture old upstream','refs/remotes/origin/main',OLD]);run(CHECKOUT,['update-ref','-m','local fixture current upstream','refs/remotes/origin/main',MAIN]);pull('main',TARGET,'ancestor_ref_reflog')
fresh();run(CHECKOUT,['update-ref','--create-reflog','-m','local fixture old target upstream','refs/remotes/origin/main',TARGET]);run(CHECKOUT,['update-ref','-m','local fixture rewound upstream','refs/remotes/origin/main',MAIN]);pull('main',TARGET,'rewound_ref_reflog')
tree=run(ORIGIN,['rev-parse',TARGET+'^{tree}']).stdout.strip();linear=run(ORIGIN,['commit-tree',tree,'-p',MAIN],input='Local-only linear control for Komodo rebase diagnosis\n').stdout.strip();fresh(linear);pull('main',linear,'linear_ahead_control')
fresh('06c0a1befa6b9516e97ee04b94dd44af8b11d220');pull('main',TARGET,'fresh_divergent_06c')
fresh('b1f96106b9d0442ee4e044451ce51e53f64ee71f');pull('main',TARGET,'fresh_divergent_issue215_head')
(ROOT/'fresh-summary.json').write_text(json.dumps({'localOnly':True,'gitVersion':run(ROOT,['--version']).stdout.strip(),'linearControlCommit':linear,'results':RESULTS},indent=2)+'\n')
