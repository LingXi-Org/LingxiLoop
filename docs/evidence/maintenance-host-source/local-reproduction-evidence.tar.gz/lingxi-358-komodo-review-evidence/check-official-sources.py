import urllib.request,concurrent.futures,pathlib,hashlib,json
out=pathlib.Path('/tmp/lingxi-358-komodo-git-repro');base='https://raw.githubusercontent.com/moghtech/komodo/v2.3.3/'
files=[('lib/git/src/pull.rs','/tmp/komodo-233-git-pull.rs'),('lib/git/src/clone.rs','/tmp/komodo-233-git-clone.rs'),('lib/git/src/pull_or_clone.rs','/tmp/komodo-233-git-pull_or_clone.rs'),('bin/periphery/src/stack/write.rs','/tmp/issue216-komodo233-source/periphery-stack-write.rs'),('bin/periphery/src/api/compose.rs','/tmp/issue216-komodo233-source/periphery-compose.rs'),('bin/core/src/api/write/stack.rs','/tmp/komodo-233-core-write-stack.rs'),('bin/core/src/stack/remote.rs',str(out/'official-core-remote.rs')),('client/core/rs/src/entities/mod.rs',str(out/'official-client-entities.rs'))]
def one(item):
 path,local=item;url=base+path
 try:
  with urllib.request.urlopen(url,timeout=30) as r:b=r.read(500000)
  target=out/('official-'+path.replace('/','-'));target.write_bytes(b)
  return {'url':url,'file':target.name,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'matchesPreviouslyRead':b==pathlib.Path(local).read_bytes()}
 except Exception as e:return {'url':url,'errorClass':type(e).__name__}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(one,files))
(out/'official-sources.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
