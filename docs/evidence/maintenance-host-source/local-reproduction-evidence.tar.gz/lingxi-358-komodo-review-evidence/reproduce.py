import os,subprocess,time,json,pathlib,hashlib
ROOT=pathlib.Path(os.environ.get('KOMODO_LOCAL_REPRO_DIR','/tmp/lingxi-358-komodo-git-repro'));ROOT.mkdir(parents=True,exist_ok=True); SOURCE='/workspace/LingxiLoop-integration-215-216-219'; OBJECTS=os.environ.get('KOMODO_REPRO_OBJECTS','/workspace/LingxiLoop/.git/objects')
MAIN='c6c47bddeabb4488f9fe93391f15c695a528260c';OLD='5d00ad7e379d82ea8b5ab35c10af775b155717f2';TARGET='f56db73dabbaec1e92a421bbad76c239ed8d1ae2';BRANCH='release/production-358-20261020';DIV='06c0a1befa6b9516e97ee04b94dd44af8b11d220'
ORIGIN=ROOT/'origin.git';CHECKOUT=ROOT/'checkout';EVENTS=[]
env={k:v for k,v in os.environ.items() if not(k.startswith('GIT_') or k in ['SSH_ASKPASS'])}
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_TERMINAL_PROMPT':'0','GIT_ALLOW_PROTOCOL':'file','GIT_EDITOR':'true','GIT_SEQUENCE_EDITOR':'true'})
base=['git','-c','core.hooksPath=/dev/null','-c','protocol.file.allow=always','-c','user.name=leecyang','-c','user.email=164771957+leecyang@users.noreply.github.com']
def run(cwd,args,tag='setup',required=True):
 start=time.monotonic();p=subprocess.run(base+args,cwd=cwd,env=env,text=True,capture_output=True,timeout=120)
 row={'tag':tag,'cwd':str(cwd),'args':args,'code':p.returncode,'elapsedMs':round((time.monotonic()-start)*1000,2),'stdout':p.stdout,'stderr':p.stderr};EVENTS.append(row)
 (ROOT/'commands.json').write_text(json.dumps(EVENTS,indent=2)+'\n')
 if required and p.returncode:raise RuntimeError(json.dumps(row))
 return p

def state():
 return {'head':run(CHECKOUT,['rev-parse','HEAD'],'state').stdout.strip(),'tree':run(CHECKOUT,['rev-parse','HEAD^{tree}'],'state').stdout.strip(),'branch':run(CHECKOUT,['symbolic-ref','--short','HEAD'],'state',False).stdout.strip(),'rebaseMerge':(CHECKOUT/'.git/rebase-merge').exists(),'rebaseApply':(CHECKOUT/'.git/rebase-apply').exists(),'conflicts':run(CHECKOUT,['diff','--name-only','--diff-filter=U'],'state').stdout.splitlines()}
def set_state(commit,branch='main'):
 if (CHECKOUT/'.git/rebase-merge').exists() or (CHECKOUT/'.git/rebase-apply').exists():run(CHECKOUT,['rebase','--abort'])
 run(CHECKOUT,['checkout','-f','-B',branch,commit]);run(CHECKOUT,['branch','--set-upstream-to=origin/'+branch,branch])
def pull(branch,pin,name):
 before=state();rows=[]
 for args in [['remote','set-url','origin',str(ORIGIN)],['fetch','--all','--prune'],['checkout','-f',branch],['pull','--rebase','--force','origin',branch],['reset','--hard',pin]]:
  p=run(CHECKOUT,args,name,False);rows.append({'args':args,'code':p.returncode})
  if p.returncode:break
 result={'name':name,'branch':branch,'pin':pin,'before':before,'after':state(),'success':all(r['code']==0 for r in rows),'commands':rows};RESULTS.append(result);(ROOT/'results.json').write_text(json.dumps(RESULTS,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['commands','before'] }),flush=True);return result
RESULTS=[]
run(ROOT,['init','--bare',str(ORIGIN)]);(ORIGIN/'objects/info/alternates').write_text(OBJECTS+'\n')
run(ORIGIN,['update-ref','refs/heads/main',MAIN]);run(ORIGIN,['update-ref','refs/heads/'+BRANCH,TARGET]);run(ORIGIN,['symbolic-ref','HEAD','refs/heads/main'])
run(ROOT,['clone','--shared',str(ORIGIN),str(CHECKOUT),'-b','main']);run(CHECKOUT,['config','gc.auto','0'])
set_state(OLD)
for i in range(3):pull('main',OLD,'old_pin_behind_main_'+str(i+1))
pull('main',TARGET,'transition_old_to_target')
for i in range(3):pull('main',TARGET,'target_ahead_of_main_'+str(i+1))
for i in range(3):pull(BRANCH,TARGET,'matching_release_branch_'+str(i+1))
set_state(DIV)
pull('main',TARGET,'genuinely_divergent_06c_to_main')
if (CHECKOUT/'.git/rebase-merge').exists():
 pull('main',TARGET,'interrupted_rebase_retry_main')
 pull(BRANCH,TARGET,'interrupted_rebase_switch_release')
set_state(TARGET)
# Contrived remote-tracking reflog with a prior branch tip that is not ancestor of current remote main.
run(CHECKOUT,['update-ref','--create-reflog','-m','local fixture previous remote target','refs/remotes/origin/main',TARGET]);run(CHECKOUT,['update-ref','-m','local fixture remote rewind','refs/remotes/origin/main',MAIN])
pull('main',TARGET,'remote_rewind_forkpoint_fixture')
# Existing historical issue215 branch before merging onto current main.
set_state('b1f96106b9d0442ee4e044451ce51e53f64ee71f')
pull('main',TARGET,'historical_issue215_head_divergent')
if (CHECKOUT/'.git/rebase-merge').exists():
 pull(BRANCH,TARGET,'historical_conflicted_cache_switch_release')
set_state(TARGET,BRANCH)
for i in range(3):pull(BRANCH,TARGET,'release_after_local_cleanup_'+str(i+1))
summary={'gitVersion':run(ROOT,['--version']).stdout.strip(),'sourceObjectStore':OBJECTS,'originMain':MAIN,'originalPin':OLD,'targetPin':TARGET,'releaseBranch':BRANCH,'results':RESULTS,'localOnly':True}
(ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
